'use client'
import AboutSection from '@/src/components/common/AboutSection'

export default function AboutPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <AboutSection />
    </div>
  )
} 